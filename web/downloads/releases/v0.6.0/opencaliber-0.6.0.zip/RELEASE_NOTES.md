# OpenCaliber 0.6.0

2026-11-12 - Connected agent reliability and versioned downloads

- Monitor connected agents in a searchable table with run-status filters and counted problems and coverage gaps.
- Develop and test detection checks with optional coding models; retain saved-run regression tests.
- Inspect reported multi-agent trajectories and compare agent versions on shared cases.
- Download 68 instrumented agent packs with explicit outcomes, tool graphs and a fixture comparison helper.
- Read the public Developer Guide and updated walkthrough; download immutable versions from Releases.
