# OpenCaliber 0.7.0

2026-11-12 - Observe Python agents without tool wrappers

- Connect existing Python scripts through a startup launcher without editing individual tool functions; remove monitoring by restoring the original command.
- Capture default SQLite and urllib activity, plus installed synchronous Requests and HTTPX calls, with payload minimization and bounded capture.
- Evaluate observed calls against console policies after execution and label launcher connections as observation-only even under blocking policies.
- Updated connection journey, public developer guide, console screenshot and runnable example with explicit coverage and evidence limits.
