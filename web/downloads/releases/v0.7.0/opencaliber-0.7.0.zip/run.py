from opencaliber.agent_server import initialize, Handler
from http.server import ThreadingHTTPServer
if __name__ == '__main__':
    initialize()
    print('OpenCaliber: http://127.0.0.1:8787/console', flush=True)
    ThreadingHTTPServer(('127.0.0.1',8787),Handler).serve_forever()
